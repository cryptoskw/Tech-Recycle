(function(){
  function load(id, url){
    var el=document.getElementById(id); if(!el) return Promise.resolve();
    return fetch(url).then(function(r){ if(!r.ok) throw new Error(url); return r.text(); }).then(function(html){ el.innerHTML=html; });
  }
  Promise.all([load('site-header','/partials/header.html?v=5'), load('site-footer','/partials/footer.html?v=5')]).then(function(){
    document.dispatchEvent(new CustomEvent('techrecycle:includes-loaded'));
  }).catch(function(err){ console.warn('Include failed', err); });
})();
