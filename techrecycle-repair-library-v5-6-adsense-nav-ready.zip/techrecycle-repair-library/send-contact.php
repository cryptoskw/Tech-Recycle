<?php
// TechRecycle contact form handler.
// Upload to hosting with PHP mail() enabled. Sends enquiries to info@techrecycle.co.za.

$to = 'info@techrecycle.co.za';
$siteName = 'TechRecycle';

function clean_field($value) {
    $value = trim((string)$value);
    $value = str_replace(["\r", "\n"], ' ', $value);
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}
function clean_message($value) {
    $value = trim((string)$value);
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}
function page_header($title) {
    echo '<!doctype html><html lang="en-ZA"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex, follow"><title>' . $title . ' | TechRecycle</title><link rel="icon" href="/assets/icons/favicon.png" type="image/png"><link rel="apple-touch-icon" href="/assets/icons/apple-touch-icon.png"><link rel="stylesheet" href="/assets/css/styles.css?v=5.6"><script src="/assets/js/includes.js?v=5.6" defer></script><script src="/assets/js/silos.js?v=5.6" defer></script><script src="/assets/js/posts.js?v=5.6" defer></script><script src="/assets/js/main.js?v=5.6" defer></script></head><body data-page="static"><div id="site-header"></div><main id="main-content"><section class="page-hero"><div class="container article-container"><p class="eyebrow">TechRecycle</p><h1>' . $title . '</h1></div></section><section class="section"><div class="container article-container"><div class="article-content">';
}
function page_footer() {
    echo '</div></div></section></main><div id="site-footer"></div></body></html>';
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /contact/');
    exit;
}

// Honeypot anti-spam field. Real users should never fill this.
if (!empty($_POST['website_url'] ?? '')) {
    header('Location: /contact/?sent=1');
    exit;
}

$name = clean_field($_POST['name'] ?? '');
$email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
$phone = clean_field($_POST['phone'] ?? '');
$company = clean_field($_POST['company'] ?? '');
$service = clean_field($_POST['service'] ?? '');
$quantity = clean_field($_POST['quantity'] ?? '');
$area = clean_field($_POST['area'] ?? '');
$dataStatus = clean_field($_POST['data_status'] ?? '');
$pageSource = clean_field($_POST['page_source'] ?? 'Website contact form');
$message = clean_message($_POST['message'] ?? '');

if ($name === '' || !$email || $message === '') {
    page_header('Message not sent');
    echo '<div class="callout warning"><strong>Please complete the required fields.</strong><p>Name, valid email address, and message are required.</p></div><p><a class="button primary" href="/contact/">Return to contact form</a></p>';
    page_footer();
    exit;
}

$subject = 'TechRecycle enquiry: ' . ($service ?: 'Website contact');
$body = "New TechRecycle website enquiry\n\n";
$body .= "Name: {$name}\n";
$body .= "Email: {$email}\n";
$body .= "Phone: {$phone}\n";
$body .= "Company: {$company}\n";
$body .= "Service: {$service}\n";
$body .= "Estimated quantity: {$quantity}\n";
$body .= "Area / pickup area: {$area}\n";
$body .= "Data status: {$dataStatus}\n";
$body .= "Source page: {$pageSource}\n\n";
$body .= "Message:\n{$message}\n\n";
$body .= "---\nSent from techrecycle.co.za";

$headers = [];
$headers[] = 'From: TechRecycle Website <info@techrecycle.co.za>';
$headers[] = 'Reply-To: ' . $name . ' <' . $email . '>';
$headers[] = 'Content-Type: text/plain; charset=UTF-8';
$headers[] = 'X-Mailer: PHP/' . phpversion();

$sent = mail($to, $subject, html_entity_decode($body, ENT_QUOTES, 'UTF-8'), implode("\r\n", $headers));

if ($sent) {
    page_header('Message sent');
    echo '<div class="callout answer"><strong>Thank you. Your message has been sent to TechRecycle.</strong><p>We will review the recycling or repair enquiry and reply using the contact details you provided.</p></div><p><a class="button primary" href="/">Back to homepage</a> <a class="button secondary" href="/blog/">Browse articles</a></p>';
    page_footer();
    exit;
}

page_header('Message could not be sent');
echo '<div class="callout warning"><strong>The website could not send the email.</strong><p>This can happen if PHP mail is disabled by the hosting account. Please email us directly at <a href="mailto:info@techrecycle.co.za">info@techrecycle.co.za</a>.</p></div><p><a class="button primary" href="mailto:info@techrecycle.co.za">Email TechRecycle directly</a></p>';
page_footer();
?>